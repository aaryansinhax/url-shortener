# Shawty URL Shortener - Project Context

## Project Overview
Shawty is a Django-based web application designed to provide URL shortening services. The project uses Django 4.2.7 and follows the standard Django project structure with a main project directory (`shawty`) and a dedicated app for the shortening functionality (`shortner`).

### Project Structure
```
C:\Users\mrsin\Documents\Portfolio\python\url-shortner\
├───db.sqlite3
├───manage.py
├───shawty\                 # Main Django project
│   ├───__init__.py
│   ├───asgi.py
│   ├───settings.py
│   ├───urls.py
│   ├───wsgi.py
│   └───__pycache__\
└───shortner\               # URL shortening app
    ├───__init__.py
    ├───admin.py
    ├───apps.py
    ├───models.py
    ├───tests.py
    ├───views.py
    └───migrations\
```

### Technology Stack
- Python 3.13
- Django 4.2.7
- SQLite3 (default database)
- Windows OS environment

## Project Configuration

### Settings
The project uses standard Django settings with:
- `DEBUG = True` (development mode)
- SQLite3 database (`db.sqlite3`)
- Default Django security settings
- Standard middleware stack
- Default authentication and content types

**Note**: The `shortner` app is not yet included in the `INSTALLED_APPS` setting, which suggests the app may need to be registered before it's fully functional.

## Current State
The project is in early development stages with basic Django structure in place:
- The `shortner` app has empty models.py and views.py files
- No custom URL routing implemented yet
- Default Django admin interface available
- Database file exists (db.sqlite3)
- No migrations have been created for the shortner app yet

## Building and Running

### Prerequisites
- Python 3.13
- Django 4.2.7 (or compatible version)

### Setup Instructions
1. Navigate to the project directory
2. Install Django: `pip install django`
3. Register the `shortner` app in `shawty/settings.py` by adding `'shortner'` to the `INSTALLED_APPS` list
4. Create and apply migrations: `python manage.py makemigrations` and `python manage.py migrate`
5. Create a superuser: `python manage.py createsuperuser`
6. Start the development server: `python manage.py runserver`

### Key Commands
- `python manage.py runserver` - Start development server
- `python manage.py makemigrations` - Create migration files for model changes
- `python manage.py migrate` - Apply database migrations
- `python manage.py createsuperuser` - Create admin user
- `python manage.py shell` - Open Django shell

## Development Conventions

### Django Best Practices
- Follow Django's Model-View-Template (MVT) architecture
- Use Django's built-in admin interface for content management
- Implement proper URL routing using Django's path() function
- Follow Django naming conventions for models, views, and templates

### App Structure
- Models in `models.py`
- Views in `views.py`
- URL patterns in `urls.py` (to be created in shortner app)
- Admin configuration in `admin.py`

## Future Development Tasks
Based on the current state, the following would be required to complete the URL shortener functionality:
1. Define URL models in `shortner/models.py`
2. Create views for URL shortening and redirection in `shortner/views.py`
3. Set up URL patterns in `shortner/urls.py` and include in main `shawty/urls.py`
4. Add `'shortner'` to `INSTALLED_APPS` in `shawty/settings.py`
5. Create and run migrations after defining models
6. Develop the frontend templates
7. Implement security measures for URL validation
8. Add functionality for custom short URLs
9. Implement analytics for tracking URL usage

## File Details

### shawty/settings.py
- Contains standard Django configuration
- Uses SQLite3 database
- Development settings with DEBUG mode enabled

### shortner/models.py
- Currently empty, needs URL model definition

### shortner/views.py
- Currently empty, needs view functions for shortening and redirecting URLs

### manage.py
- Standard Django management script
- Used for administrative tasks like running the server and migrations

## Database
- SQLite3 database file: `db.sqlite3`
- No custom models currently registered, so no tables specific to URL shortening yet