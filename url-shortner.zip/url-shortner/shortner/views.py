from django.shortcuts import render
from django.http import HttpResponse
from .models import Url
import uuid
from django.shortcuts import redirect 

def index(request):
    context={'peter':'family guy', 'pepa':'i am pepa pig'}
    urls = Url.objects.all()
    return render(request, "shortner/home.html", {'urls': urls})

def submit_url(request):
    if request.method == "POST":
        original_url = str(request.POST.get("ogUrl")).strip()

        # Remove protocol if present to store just the domain/path
        if original_url.startswith(('http://', 'https://')):
            original_url = original_url.split("://", 1)[1]

        uid = uuid.uuid1()
        uid = str(uid)
        short_url = uid[:6]
        short_url = str(short_url)

        Url.objects.create(ogUrl=original_url, shortUrl=short_url)
        return redirect("/")
    return HttpResponse("Invalid request method.")

def redirect_url(request, short_code):
    try:
        print("Received short code:", short_code)
        entry = Url.objects.get(shortUrl=short_code)

        original_url = entry.ogUrl

        # Check if the URL already has a protocol (http:// or https://)
        if not original_url.startswith(('http://', 'https://')):
            # Add http:// if no protocol is present
            original_url = 'http://' + original_url

        return redirect(original_url)
    except Url.DoesNotExist:
        return HttpResponse("URL not found.", status=404)

def test_view(request):
    return HttpResponse("This is a test view.")
