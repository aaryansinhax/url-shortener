from django.db import models

# Create your models here.

class Url(models.Model):
    ogUrl = models.CharField(max_length=200)
    shortUrl = models.CharField(max_length=200)
    def __str__(self):
        return self.ogUrl

